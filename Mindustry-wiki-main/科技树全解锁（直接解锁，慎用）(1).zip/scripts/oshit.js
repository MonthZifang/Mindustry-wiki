Events.on(ClientLoadEvent, cons(e => {
    Seq.with(Vars.content.getContentMap()).flatten().each(cons(v => {
        if (v instanceof UnlockableContent) {
            v.unlock();
        }
    }))
}))

